package com.example.request_sender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RequestSenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
