package com.example.request_sender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RequestSenderApplication {

	public static void main(String[] args) {
		SpringApplication.run(RequestSenderApplication.class, args);
	}

}
